# Netbeans-BM-w-loginform
Calculate the Body Mass
