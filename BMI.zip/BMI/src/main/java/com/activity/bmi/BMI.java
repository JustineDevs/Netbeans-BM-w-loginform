/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.activity.bmi;

/**
 *
 * @author TraderG
 */
public class BMI {

    public static void main(String[] args) {
        Preview view = new Preview();
        view.show();
    }
}
